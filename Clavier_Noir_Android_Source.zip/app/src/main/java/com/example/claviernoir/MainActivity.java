package com.example.claviernoir;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import android.graphics.Color;
import android.view.Gravity;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 32, 24, 24);
        root.setBackgroundColor(Color.rgb(12,12,14));
        TextView title = new TextView(this);
        title.setText("Clavier Noir");
        title.setTextColor(Color.WHITE); title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView sub = new TextView(this);
        sub.setText("AZERTY • Français • thème noir • sans son");
        sub.setTextColor(Color.LTGRAY); sub.setGravity(Gravity.CENTER);
        sub.setPadding(0,12,0,24); root.addView(sub);
        Button enable = new Button(this);
        enable.setText("1. Activer Clavier Noir");
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        root.addView(enable);
        Button choose = new Button(this);
        choose.setText("2. Choisir Clavier Noir");
        choose.setOnClickListener(v -> {
            InputMethodManager imm=(InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showInputMethodPicker();
        });
        root.addView(choose);
        TextView info = new TextView(this);
        info.setText("\nFonctions prévues dans cette première version :\n• AZERTY français\n• thème sombre\n• emojis\n• presse-papiers Android\n• taille réglable avec − / +\n• aucun son ni touche micro\n\nPour l’utiliser : active-le dans les paramètres, puis choisis-le dans le sélecteur de clavier.");
        info.setTextColor(Color.WHITE); info.setTextSize(16); info.setPadding(0,24,0,0);
        root.addView(info);
        setContentView(root);
    }
}
