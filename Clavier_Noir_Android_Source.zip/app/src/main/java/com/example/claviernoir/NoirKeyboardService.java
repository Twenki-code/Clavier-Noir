package com.example.claviernoir;

import android.inputmethodservice.InputMethodService;
import android.view.*;
import android.view.inputmethod.InputConnection;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;

public class NoirKeyboardService extends InputMethodService {
    private LinearLayout root, keysArea;
    private float keyScale = 1f;
    private boolean shift = true;
    private final int bg = Color.rgb(5,5,7), key = Color.rgb(43,45,50), fg = Color.rgb(245,246,250);

    @Override public View onCreateInputView() {
        SharedPreferences p=getSharedPreferences("keyboard", MODE_PRIVATE);
        keyScale=p.getFloat("scale",1f);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(5,5,5,6); root.setBackgroundColor(bg);
        LinearLayout toolbar=new LinearLayout(this); toolbar.setGravity(Gravity.CENTER);
        addTool(toolbar,"▤",()->pasteClipboard());
        addTool(toolbar,"☺",()->insert("😊"));
        addTool(toolbar,"−",()->resize(-0.1f));
        addTool(toolbar,"+",()->resize(0.1f));
        root.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(42)));
        keysArea=new LinearLayout(this); keysArea.setOrientation(LinearLayout.VERTICAL);
        root.addView(keysArea,new LinearLayout.LayoutParams(-1,-2));
        buildKeys();
        return root;
    }
    private int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density); }
    private GradientDrawable shape(int color) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(7)); return d;
    }
    private void addTool(LinearLayout row,String label,Runnable action) {
        TextView t=new TextView(this); t.setText(label); t.setTextColor(fg); t.setTextSize(21);
        t.setGravity(Gravity.CENTER); t.setBackground(shape(Color.rgb(20,21,24)));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(36),1); lp.setMargins(dp(3),0,dp(3),0);
        row.addView(t,lp); t.setOnClickListener(v->action.run());
    }
    private void buildKeys() {
        keysArea.removeAllViews();
        String[] rows={"AZERTYUIOP","QSDFGHJKLM","⇧WXCVBN⌫"};
        for(int r=0;r<rows.length;r++){
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER);
            String chars=rows[r];
            for(int i=0;i<chars.length();i++){
                final String c=chars.substring(i,i+1);
                TextView t=new TextView(this); t.setText(c); t.setTextColor(fg);
                t.setTypeface(Typeface.DEFAULT,Typeface.NORMAL); t.setTextSize(19*keyScale);
                t.setGravity(Gravity.CENTER); t.setBackground(shape(key));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(47*keyScale),1);
                lp.setMargins(dp(2),dp(3),dp(2),dp(3)); row.addView(t,lp);
                t.setOnClickListener(v->{
                    if(c.equals("⌫")){ InputConnection ic=getCurrentInputConnection(); if(ic!=null)ic.deleteSurroundingText(1,0); }
                    else if(c.equals("⇧")){shift=!shift; buildKeys();}
                    else insert(shift?c:c.toLowerCase());
                });
            }
            keysArea.addView(row);
        }
        LinearLayout bottom=new LinearLayout(this); bottom.setGravity(Gravity.CENTER);
        addBottom(bottom,"123",()->insert("123"));
        addBottom(bottom,"😀",()->insert("😀"));
        addBottom(bottom,"espace",()->insert(" "));
        addBottom(bottom,".",()->insert("."));
        addBottom(bottom,"retour",()->{InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.commitText("\n",1);});
        keysArea.addView(bottom);
    }
    private void addBottom(LinearLayout row,String s,Runnable action) {
        TextView t=new TextView(this);t.setText(s);t.setTextColor(fg);t.setTextSize(13*keyScale);
        t.setGravity(Gravity.CENTER);t.setBackground(shape(key));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48*keyScale),s.equals("espace")?2:1);
        lp.setMargins(dp(2),dp(3),dp(2),dp(3));row.addView(t,lp);t.setOnClickListener(v->action.run());
    }
    private void insert(String s){InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.commitText(s,1);}
    private void resize(float d){
        keyScale=Math.max(0.75f,Math.min(1.25f,keyScale+d));
        getSharedPreferences("keyboard",MODE_PRIVATE).edit().putFloat("scale",keyScale).apply();
        buildKeys();
    }
    private void pasteClipboard(){
        ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        if(cm!=null && cm.hasPrimaryClip()){
            ClipData clip=cm.getPrimaryClip();
            if(clip!=null&&clip.getItemCount()>0){
                CharSequence text=clip.getItemAt(0).coerceToText(this);
                if(text!=null)insert(text.toString());
            }
        }
    }
}
