CLAVIER NOIR — projet Android source
===================================

Fonctions de cette première base :
- Service de clavier Android (IME)
- disposition AZERTY française simple
- thème noir/gris, touches arrondies
- aucun son ajouté
- raccourci presse-papiers (colle le texte copié dans Android)
- emoji rapide
- taille des touches réglable avec − et +
- aucun bouton microphone

IMPORTANT :
Ce fichier ZIP contient le CODE SOURCE du projet, pas un APK déjà compilé.
Pour générer l’APK, ouvre le dossier dans Android Studio sur un ordinateur,
laisse Gradle synchroniser, puis lance Build > Build APK(s).
Le clavier est une première version de base : les touches 123 et les emojis
sont encore simples, et l’interface peut nécessiter des ajustements selon
la version d’Android. Teste-le avant de l’utiliser comme clavier principal.

Installation après compilation :
1. Installe l’APK sur le téléphone.
2. Ouvre Clavier Noir.
3. Appuie sur « Activer Clavier Noir » et active-le dans les paramètres.
4. Appuie sur « Choisir Clavier Noir » puis sélectionne-le.
